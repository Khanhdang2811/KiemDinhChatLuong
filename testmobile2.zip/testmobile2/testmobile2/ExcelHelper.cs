﻿using System;
using ClosedXML.Excel;

namespace testmobile2
{
	public class ExcelHelper
	{
        private string excelFilePath;

        public ExcelHelper(string filePath)
        {
            excelFilePath = filePath;
        }

        public void WriteResultToExcel(string testCaseName, string expectedResult, string actualResult, string passOrFail, int rowIndex)
        {
            using (var workbook = new XLWorkbook(excelFilePath))
            {
                var worksheet = workbook.Worksheet(1);

                // Ghi kết quả mong muốn vào cột 5, hàng được chỉ định
                worksheet.Cell(rowIndex, 5).Value = expectedResult;
                // Ghi kết quả thực tế vào cột 6, hàng được chỉ định
                worksheet.Cell(rowIndex, 6).Value = actualResult;
                // Ghi kết quả pass/fail vào cột 7, hàng được chỉ định
                worksheet.Cell(rowIndex, 7).Value = passOrFail;

                // Lưu lại file Excel
                workbook.Save();
            }
        }


        public string GetTestData(string testCaseName, int row)
        {
            string testData = null;
            using (var workbook = new XLWorkbook(excelFilePath))
            {
                var worksheet = workbook.Worksheet(1);

                // Bắt đầu từ hàng thứ hai (hàng đầu tiên chứa tiêu đề)
                int rowCount = worksheet.RowsUsed().Count();

                for (int i = 2; i <= rowCount; i++)
                {
                    if (worksheet.Cell(i, 1).Value.ToString() == testCaseName)
                    {
                        // Lấy dữ liệu từ cột thứ tư của hàng đã chỉ định
                        testData = worksheet.Cell(row, 4).Value.ToString();
                        break;
                    }
                }
            }
            return testData;
        }
    }
}

