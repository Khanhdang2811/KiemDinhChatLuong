﻿using ClosedXML.Excel;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
namespace testmobile2;
public class Tests
{
    IWebDriver driver;
    string url;
    [SetUp]
    public void Setup()
    {
        driver = new ChromeDriver();
        url = "https://www.demoblaze.com/";
    }
    [Test]
    [TearDown]
    public void TearDown()
    {
        Thread.Sleep(1000);
        driver.Quit();
    }
    //--------------------------------------------------------------------------------------------------------------------------//
    

    //--------------------------------------------------------------------------------------------------------------------------//
    [Test]
    public void TestDangKi()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_01"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 2);
        string[] testDataParts = testData.Split(',');

        // Thực hiện test case dựa trên dữ liệu test
        driver.Navigate().GoToUrl(url);
        Thread.Sleep(1000);
        driver.FindElement(By.Id("signin2")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("sign-username")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("sign-username")).SendKeys(testDataParts[0].Trim()); // Tên người dùng
        Thread.Sleep(500);
        driver.FindElement(By.Id("sign-password")).SendKeys(testDataParts[1].Trim()); // Mật khẩu
        Thread.Sleep(500);
        driver.FindElement(By.CssSelector("#signInModal .btn-primary")).Click();
        Thread.Sleep(1000);

        // Kiểm tra kết quả và ghi vào file Excel
        string expectedResult = "Sign up successful.";
        string actualResult = driver.SwitchTo().Alert().Text;
        // Kiểm tra kết quả và ghi vào file Excel
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";
        // Ghi kết quả vào file Excel
        try
        {
            string alertText = driver.SwitchTo().Alert().Text;

            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail,2);
        }
        catch (IOException ex)
        {
            // Xử lý ngoại lệ IO ở đây, ví dụ: thử lại sau một khoảng thời gian
            Thread.Sleep(1000); // Đợi 1 giây trước khi thử lại
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail,2); // Thử ghi lại
        }


        // Assert để kiểm tra kết quả
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }





    [Test]
    public void TestDangNhap()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_02"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 3);
        string[] testDataParts = testData.Split(',');

        // Thực hiện test case dựa trên dữ liệu test
        driver.Navigate().GoToUrl(url);
        Thread.Sleep(1000);
        driver.FindElement(By.Id("login2")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("loginusername")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("loginusername")).SendKeys(testDataParts[0].Trim()); // Tên người dùng
        Thread.Sleep(500);
        driver.FindElement(By.Id("loginpassword")).SendKeys(testDataParts[1].Trim()); // Mật khẩu
        Thread.Sleep(500);
        driver.FindElement(By.CssSelector("#logInModal .btn-primary")).Click();
        Thread.Sleep(3000);

        // Kiểm tra kết quả và ghi vào file Excel
        string expectedResult = "Sign in successful";
        string actualResult = string.Empty;
        string passOrFail = string.Empty;
        try
        {
            driver.FindElement(By.Id("nameofuser")).Click();
            actualResult = expectedResult; // Nếu click thành công thì kết quả là "Sign in successful"
            passOrFail = "Pass";
        }
        catch (NoSuchElementException)
        {
            actualResult = "No element found"; // Nếu không tìm thấy phần tử thì kết quả là "No element found"
            passOrFail = "Fail";
        }

        // Ghi kết quả vào file Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 3);
        }
        catch (IOException ex)
        {
            // Xử lý ngoại lệ IO ở đây, ví dụ: thử lại sau một khoảng thời gian
            Thread.Sleep(1000); // Đợi 1 giây trước khi thử lại
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 3); // Thử ghi lại
        }

        // Assert để kiểm tra kết quả
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }

    //-----------------------------------------------------------------------------------------------------------------------------------------

    [Test]
    public void TestThemVaoGioHang()
    {
          // Đường dẫn tới file Excel chứa test case
           string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
            // Khởi tạo đối tượng ExcelHelper
            ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

            // Đọc dữ liệu test từ file Excel
            string testCaseName = "TC_03"; // Tên test case
            string testData = excelHelper.GetTestData(testCaseName, 4);
            string[] testDataParts = testData.Split(',');
        driver.Navigate().GoToUrl("https://www.demoblaze.com/");
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText("Samsung galaxy s6")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText("Add to cart")).Click();
        Thread.Sleep(1000);
        // Kiểm tra kết quả và ghi vào file Excel
        string expectedResult = "Product added";
        string actualResult = driver.SwitchTo().Alert().Text;
        // Kiểm tra kết quả và ghi vào file Excel
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";
        // Ghi kết quả vào file Excel
        try
        {
            string alertText = driver.SwitchTo().Alert().Text;

            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 4);
        }
        catch (IOException ex)
        {
            // Xử lý ngoại lệ IO ở đây, ví dụ: thử lại sau một khoảng thời gian
            Thread.Sleep(1000); // Đợi 1 giây trước khi thử lại
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 4); // Thử ghi lại
        }


        // Assert để kiểm tra kết quả
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }


    [Test]
    public void TestXoaKhoiGioHang()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_04"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 5);
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl("https://www.demoblaze.com/");
        Thread.Sleep(1000);

        // Find the product and add it to cart
        driver.FindElement(By.LinkText(testDataParts[0].Trim())).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText("Add to cart")).Click();
        Thread.Sleep(1000);
        driver.SwitchTo().Alert().Accept();
        Thread.Sleep(1000);

        // Go to Cart and delete the product
        driver.FindElement(By.LinkText("Cart")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText("Delete")).Click();
        Thread.Sleep(1000);

        // Check if the element still exists after deletion
        bool isElementPresent;
        try
        {
            driver.FindElement(By.LinkText("Delete"));
            isElementPresent = true; 
        }
        catch (NoSuchElementException)
        {
            isElementPresent = false; 
        }
        string expectedResult = "pass"; // Nếu liên kết "Delete" không còn tồn tại, kết quả là "pass"
        string actualResult = isElementPresent ? "fail" : "pass"; // Nếu mục vẫn tồn tại, kết quả là "fail", ngược lại là "pass"
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 5);
        }
        catch (IOException ex)
        {
            // Handle IO exception here, e.g., retry after some time
            Thread.Sleep(1000); // Wait for 1 second before retrying
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 5); // Retry
        }

        // Assert to check the result
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }



    //-----------------------------------------------------------------------------------------------------------------------------------------
    [Test]
    public void TestXemDanhMucLaptop()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_05"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 6);
        string[] testDataParts = testData.Split(',');

        driver.Navigate().GoToUrl("https://www.demoblaze.com/");
        Thread.Sleep(1000);

        // Navigate to the website
        driver.FindElement(By.LinkText(testDataParts[0].Trim())).Click();
        Thread.Sleep(500);

        // Check if the expected laptop is displayed
        string expectedResult = testDataParts[1].Trim();
        string actualResult = driver.FindElement(By.LinkText(expectedResult)).Text;
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Ghi kết quả vào file Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 6);
        }
        catch (IOException ex)
        {
            // Xử lý ngoại lệ IO ở đây, ví dụ: thử lại sau một khoảng thời gian
            Thread.Sleep(1000); // Đợi 1 giây trước khi thử lại
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 6); // Thử ghi lại
        }

        // Assert để kiểm tra kết quả
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }

    [Test]
    public void TestXemDanhMucDienThoai()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_05"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 7);
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl("https://www.demoblaze.com/");
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText(testDataParts[0].Trim())).Click();
        Thread.Sleep(500);

        // Check if the expected phone is displayed
        string expectedResult = testDataParts[1].Trim();
        string actualResult = driver.FindElement(By.LinkText(expectedResult)).Text;
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Ghi kết quả vào file Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 7);
        }
        catch (IOException ex)
        {
            // Xử lý ngoại lệ IO ở đây, ví dụ: thử lại sau một khoảng thời gian
            Thread.Sleep(1000); // Đợi 1 giây trước khi thử lại
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 7); // Thử ghi lại
        }

        // Assert để kiểm tra kết quả
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }

    [Test]
    public void TestXemDanhMucMonitor()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_07"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 8);
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl("https://www.demoblaze.com/");
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText(testDataParts[0].Trim())).Click();
        Thread.Sleep(500);

        // Check if the expected monitor is displayed
        string expectedResult = testDataParts[1].Trim();
        string actualResult = driver.FindElement(By.LinkText(expectedResult)).Text;
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Ghi kết quả vào file Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 8);
        }
        catch (IOException ex)
        {
            // Xử lý ngoại lệ IO ở đây, ví dụ: thử lại sau một khoảng thời gian
            Thread.Sleep(1000); // Đợi 1 giây trước khi thử lại
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 8); // Thử ghi lại
        }

        // Assert để kiểm tra kết quả
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }

    //-----------------------------------------------------------------------------------------------------------------------------------------
    [Test]
    //Test đăng ky bỏ trống mật khẩu
    public void RegistrationWithoutPassword()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_08"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 9);
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl("https://www.demoblaze.com/");
        Thread.Sleep(1000);
        driver.FindElement(By.Id("signin2")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("sign-username")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("sign-username")).SendKeys(testDataParts[0].Trim());
        Thread.Sleep(500);
        driver.FindElement(By.Id("sign-password")).SendKeys("");
        Thread.Sleep(500);
        driver.FindElement(By.CssSelector("#signInModal .btn-primary")).Click();
        Thread.Sleep(1000);

        // Check result and write to Excel
        string expectedResult = "Please fill out Username and Password.";
        string actualResult = driver.SwitchTo().Alert().Text;
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 9);
        }
        catch (IOException ex)
        {
            // Handle IO exception here, e.g., retry after some time
            Thread.Sleep(1000); // Wait for 1 second before retrying
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 9); // Retry
        }

        // Assert to check the result
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }

    [Test]
    //Test đăng ky bỏ trống tên đăng nhập
    public void RegistrationWithoutUsername()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_09"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 10);
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl("https://www.demoblaze.com/");
        Thread.Sleep(1000);
        driver.FindElement(By.Id("signin2")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("sign-username")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("sign-username")).SendKeys("");
        Thread.Sleep(500);
        driver.FindElement(By.Id("sign-password")).SendKeys(testDataParts[0].Trim());
        Thread.Sleep(500);
        driver.FindElement(By.CssSelector("#signInModal .btn-primary")).Click();
        Thread.Sleep(1000);

        // Check result and write to Excel
        string expectedResult = "Please fill out Username and Password.";
        string actualResult = driver.SwitchTo().Alert().Text;
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 10);
        }
        catch (IOException ex)
        {
            // Handle IO exception here, e.g., retry after some time
            Thread.Sleep(1000); // Wait for 1 second before retrying
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 10); // Retry
        }

        // Assert to check the result
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }

    [Test]
    //Test đăng ky bỏ trống tên đăng nhập và mật khẩu
    public void RegistrationWithoutUsernameAndPassword()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_10"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 11);
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl("https://www.demoblaze.com/");
        Thread.Sleep(1000);
        driver.FindElement(By.Id("signin2")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("sign-username")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("sign-username")).SendKeys("");
        Thread.Sleep(500);
        driver.FindElement(By.Id("sign-password")).SendKeys("");
        Thread.Sleep(500);
        driver.FindElement(By.CssSelector("#signInModal .btn-primary")).Click();
        Thread.Sleep(1000);

        // Check result and write to Excel
        string expectedResult = "Please fill out Username and Password.";
        string actualResult = driver.SwitchTo().Alert().Text;
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 11);
        }
        catch (IOException ex)
        {
            // Handle IO exception here, e.g., retry after some time
            Thread.Sleep(1000); // Wait for 1 second before retrying
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 11); // Retry
        }

        // Assert to check the result
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }

    [Test]
    //Test đăng ky trùng tên đăng nhập
    public void RegistrationDuplicateUsername()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_11"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 12);
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl("https://www.demoblaze.com/");
        Thread.Sleep(1000);
        driver.FindElement(By.Id("signin2")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("sign-username")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("sign-username")).SendKeys(testDataParts[0].Trim());
        Thread.Sleep(500);
        driver.FindElement(By.Id("sign-password")).SendKeys(testDataParts[1].Trim());
        Thread.Sleep(500);
        driver.FindElement(By.CssSelector("#signInModal .btn-primary")).Click();
        Thread.Sleep(1000);

        // Check result and write to Excel
        string expectedResult = "This user already exist.";
        string actualResult = driver.SwitchTo().Alert().Text;
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 12);
        }
        catch (IOException ex)
        {
            // Handle IO exception here, e.g., retry after some time
            Thread.Sleep(1000); // Wait for 1 second before retrying
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 12); // Retry
        }

        // Assert to check the result
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }

    [Test]
    //Test đăng ky thành công
    public void RegistrationSuccess()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_12"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 13);
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl("https://www.demoblaze.com/");
        Thread.Sleep(1000);
        driver.FindElement(By.Id("SignIn2")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("sign-username")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("sign-username")).SendKeys(testDataParts[0].Trim());
        Thread.Sleep(500);
        driver.FindElement(By.Id("sign-password")).SendKeys(testDataParts[1].Trim());
        Thread.Sleep(500);
        driver.FindElement(By.CssSelector("#signInModal .btn-primary")).Click();
        Thread.Sleep(1000);

        // Check result and write to Excel
        string expectedResult = "Sign up successful.";
        string actualResult = driver.SwitchTo().Alert().Text;
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 13);
        }
        catch (IOException ex)
        {
            // Handle IO exception here, e.g., retry after some time
            Thread.Sleep(1000); // Wait for 1 second before retrying
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 13); // Retry
        }

        // Assert to check the result
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }

    //-----------------------------------------------------------------------------------------------------------------------------------------
    [Test]
    // Test liên lạc với chúng tôi bỏ trống email
    public void ContactUsWithoutEmail()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_13"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 14 );
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl("https://www.demoblaze.com/");
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText("Contact")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("recipient-email")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("recipient-email")).SendKeys("");
        Thread.Sleep(500);
        driver.FindElement(By.Id("recipient-name")).SendKeys(testDataParts[0].Trim());
        Thread.Sleep(500);
        driver.FindElement(By.Id("message-text")).SendKeys(testDataParts[1].Trim());
        Thread.Sleep(500);
        driver.FindElement(By.CssSelector("#exampleModal .btn-primary")).Click();
        Thread.Sleep(1000);

        // Check result and write to Excel
        string expectedResult = "Please fill out Email";
        string actualResult = driver.SwitchTo().Alert().Text;
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 14);
        }
        catch (IOException ex)
        {
            // Handle IO exception here, e.g., retry after some time
            Thread.Sleep(1000); // Wait for 1 second before retrying
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 14); // Retry
        }

        // Assert to check the result
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }

    [Test]
    // Test liên lạc với chúng tôi bỏ trống tên
    public void ContactUsWithoutName()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_14"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 15);
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl("https://www.demoblaze.com/");
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText("Contact")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("recipient-email")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("recipient-email")).SendKeys(testDataParts[0].Trim());
        Thread.Sleep(500);
        driver.FindElement(By.Id("recipient-name")).SendKeys("");
        Thread.Sleep(500);
        driver.FindElement(By.Id("message-text")).SendKeys(testDataParts[1].Trim());
        Thread.Sleep(500);
        driver.FindElement(By.CssSelector("#exampleModal .btn-primary")).Click();
        Thread.Sleep(1000);

        // Check result and write to Excel
        string expectedResult = "Please fill out Name";
        string actualResult = driver.SwitchTo().Alert().Text;
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 15);
        }
        catch (IOException ex)
        {
            // Handle IO exception here, e.g., retry after some time
            Thread.Sleep(1000); // Wait for 1 second before retrying
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 15); // Retry
        }

        // Assert to check the result
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }

    [Test]
    // Test liên lạc với chúng tôi bỏ trống nội dung
    public void ContactUsWithoutMessage()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_15"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 16);
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl("https://www.demoblaze.com/");
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText("Contact")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("recipient-email")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("recipient-email")).SendKeys(testDataParts[0].Trim());
        Thread.Sleep(500);
        driver.FindElement(By.Id("recipient-name")).SendKeys(testDataParts[1].Trim());
        Thread.Sleep(500);
        driver.FindElement(By.Id("message-text")).SendKeys("");
        Thread.Sleep(500);
        driver.FindElement(By.CssSelector("#exampleModal .btn-primary")).Click();
        Thread.Sleep(1000);

        // Check result and write to Excel
        string expectedResult = "Please fill out Message";
        string actualResult = driver.SwitchTo().Alert().Text;
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 16);
        }
        catch (IOException ex)
        {
            // Handle IO exception here, e.g., retry after some time
            Thread.Sleep(1000); // Wait for 1 second before retrying
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 16); // Retry
        }

        // Assert to check the result
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }

    [Test]
    // Test liên lạc với chúng tôi thành công
    public void ContactUsSuccess()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_16"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 17);
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl("https://www.demoblaze.com/");
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText("Contact")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("recipient-email")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("recipient-email")).SendKeys(testDataParts[0].Trim());
        Thread.Sleep(500);
        driver.FindElement(By.Id("recipient-name")).SendKeys(testDataParts[1].Trim());
        Thread.Sleep(500);
        driver.FindElement(By.Id("message-text")).SendKeys(testDataParts[2].Trim());
        Thread.Sleep(500);
        driver.FindElement(By.CssSelector("#exampleModal .btn-primary")).Click();
        Thread.Sleep(1000);

        // Check result and write to Excel
        string expectedResult = "Thanks for the message!!";
        string actualResult = driver.SwitchTo().Alert().Text;
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 17);
        }
        catch (IOException ex)
        {
            // Handle IO exception here, e.g., retry after some time
            Thread.Sleep(1000); // Wait for 1 second before retrying
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 17); // Retry
        }

        // Assert to check the result
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }

    [Test]
    // Test liên lạc nhưng nhập sai định dạng email
    public void ContactUsWrongEmail()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_17"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 18);
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl("https://www.demoblaze.com/");
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText("Contact")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("recipient-email")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("recipient-email")).SendKeys(testDataParts[0].Trim());
        Thread.Sleep(500);
        driver.FindElement(By.Id("recipient-name")).SendKeys(testDataParts[1].Trim());
        Thread.Sleep(500);
        driver.FindElement(By.Id("message-text")).SendKeys(testDataParts[2].Trim());
        Thread.Sleep(500);
        driver.FindElement(By.CssSelector("#exampleModal .btn-primary")).Click();
        Thread.Sleep(1000);

        // Check result and write to Excel
        string expectedResult = "Please fill out Email";
        string actualResult = driver.SwitchTo().Alert().Text;
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 18);
        }
        catch (IOException ex)
        {
            // Handle IO exception here, e.g., retry after some time
            Thread.Sleep(1000); // Wait for 1 second before retrying
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 18); // Retry
        }

        // Assert to check the result
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }

    //-----------------------------------------------------------------------------------------------------------------------------------------
    [Test]
    // Test phân trang
    public void Pagination()
    {
        driver.Navigate().GoToUrl("https://www.demoblaze.com/");
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText("Laptops")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.Id("next2")).Click();
    }
    //-----------------------------------------------------------------------------------------------------------------------------------------
    [Test]
    // Test xem chi tiết sản phẩm laptop
    public void ViewDetailLaptop()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_19"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 20); // Lấy dữ liệu test từ Excel
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl(url); // Sử dụng URL từ dữ liệu test

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Click on the "Laptops" link
        driver.FindElement(By.LinkText(testDataParts[0])).Click();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Click on the "Sony vaio i5" laptop
        driver.FindElement(By.LinkText(testDataParts[1])).Click();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Check result and write to Excel
        string expectedResult = "Sony vaio i5"; // Kết quả mong đợi là tên sản phẩm
        string actualResult = driver.FindElement(By.CssSelector(".name")).Text; // Lấy tên sản phẩm từ trang
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail"; // Xác định kết quả

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail,20);
        }
        catch (IOException ex)
        {
            // Xử lý ngoại lệ IO ở đây, ví dụ: thử lại sau một khoảng thời gian
            Thread.Sleep(1000); // Đợi 1 giây trước khi thử lại
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail,20); // Thử ghi lại
        }

        // Assert để kiểm tra kết quả
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }

    [Test]
    // Test xem chi tiết sản phẩm điện thoại
    public void ViewDetailPhone()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_20"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 21); // Lấy dữ liệu test từ Excel
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl(url); // Sử dụng URL từ dữ liệu test

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Click on the "Phones" link
        driver.FindElement(By.LinkText(testDataParts[0])).Click();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Click on the "Samsung galaxy s6" phone
        driver.FindElement(By.LinkText(testDataParts[1])).Click();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Check result and write to Excel
        string expectedResult = "Samsung galaxy s6"; // Kết quả mong đợi là tên sản phẩm
        string actualResult = driver.FindElement(By.CssSelector(".name")).Text; // Lấy tên sản phẩm từ trang
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail"; // Xác định kết quả

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 21);
        }
        catch (IOException ex)
        {
            // Xử lý ngoại lệ IO ở đây, ví dụ: thử lại sau một khoảng thời gian
            Thread.Sleep(1000); // Đợi 1 giây trước khi thử lại
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 21); // Thử ghi lại
        }

        // Assert để kiểm tra kết quả
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }

    [Test]
    // Test xem chi tiết sản phẩm monitor
    public void ViewDetailMonitor()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_21"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 22); // Lấy dữ liệu test từ Excel
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl(url); // Sử dụng URL từ dữ liệu test

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Click on the "Monitors" link
        driver.FindElement(By.LinkText(testDataParts[0])).Click();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Click on the "Apple monitor 24" monitor
        driver.FindElement(By.LinkText(testDataParts[1])).Click();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Check result and write to Excel
        string expectedResult = "Apple monitor 24"; // Kết quả mong đợi là tên sản phẩm
        string actualResult = driver.FindElement(By.CssSelector(".name")).Text; // Lấy tên sản phẩm từ trang
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail"; // Xác định kết quả

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 22);
        }
        catch (IOException ex)
        {
            // Xử lý ngoại lệ IO ở đây, ví dụ: thử lại sau một khoảng thời gian
            Thread.Sleep(1000); // Đợi 1 giây trước khi thử lại
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 22); // Thử ghi lại
        }

        // Assert để kiểm tra kết quả
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }

    //-----------------------------------------------------------------------------------------------------------------------------------------
    [Test]
    // Test đặt hàng điện thoại thành công  
    public void OrderPhoneSuccess()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_22"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 23); // Lấy dữ liệu test từ Excel
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl(url); // Sử dụng URL từ dữ liệu test

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on the "Phones" link
        driver.FindElement(By.LinkText(testDataParts[0])).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on the "Samsung galaxy s6" phone
        driver.FindElement(By.LinkText(testDataParts[1])).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on "Add to cart" button
        driver.FindElement(By.LinkText("Add to cart")).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Accept the alert
        driver.SwitchTo().Alert().Accept();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Click on the "Cart" link
        driver.FindElement(By.LinkText("Cart")).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on the "Place Order" button
        driver.FindElement(By.CssSelector(".btn-success")).Click();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Fill in the order details
        driver.FindElement(By.Id("name")).SendKeys(testDataParts[2]); // Name
        Thread.Sleep(500);
        driver.FindElement(By.Id("country")).SendKeys(testDataParts[3]); // Country
        Thread.Sleep(500);
        driver.FindElement(By.Id("city")).SendKeys(testDataParts[4]); // City
        Thread.Sleep(500);
        driver.FindElement(By.Id("card")).SendKeys(testDataParts[5]); // Card Number
        Thread.Sleep(500);
        driver.FindElement(By.Id("month")).SendKeys(testDataParts[6]); // Month
        Thread.Sleep(500);
        driver.FindElement(By.Id("year")).SendKeys(testDataParts[7]); // Year
        Thread.Sleep(500);

        // Click on the "Purchase" button
        driver.FindElement(By.CssSelector("#orderModal .btn-primary")).Click();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        //// Click on the "OK" button in the confirmation dialog
        //driver.FindElement(By.CssSelector(".confirm")).Click();

        // Kiểm tra xem nút "OK" đã được click thành công hay không
        bool isOKButtonClicked = true;
        try
        {
            // Kiểm tra xem hộp thoại xác nhận đã biến mất
            driver.FindElement(By.CssSelector(".confirm"));
        }
        catch (NoSuchElementException)
        {
            // Nếu không tìm thấy nút "OK", tức là nó đã biến mất sau khi được click
            isOKButtonClicked = false;
        }

        // Kết quả mong đợi là "true" nếu nút "OK" đã được click thành công
        string expectedResult = "True";
        string actualResult = isOKButtonClicked.ToString();
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 23);
        }
        catch (IOException ex)
        {
            // Xử lý ngoại lệ IO ở đây, ví dụ: thử lại sau một khoảng thời gian
            Thread.Sleep(1000); // Đợi 1 giây trước khi thử lại
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 23); // Thử ghi lại
        }

        // Assert để kiểm tra kết quả
        Assert.That(actualResult, Is.EqualTo(expectedResult));

    }

    [Test]
    // Test đặt hàng laptop thành công
    public void OrderLaptopSuccess()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_23"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 24); // Lấy dữ liệu test từ Excel
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl(url); // Sử dụng URL từ dữ liệu test

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on the "Phones" link
        driver.FindElement(By.LinkText(testDataParts[0])).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on the "Samsung galaxy s6" phone
        driver.FindElement(By.LinkText(testDataParts[1])).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on "Add to cart" button
        driver.FindElement(By.LinkText("Add to cart")).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Accept the alert
        driver.SwitchTo().Alert().Accept();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Click on the "Cart" link
        driver.FindElement(By.LinkText("Cart")).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on the "Place Order" button
        driver.FindElement(By.CssSelector(".btn-success")).Click();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Fill in the order details
        driver.FindElement(By.Id("name")).SendKeys(testDataParts[2]); // Name
        Thread.Sleep(500);
        driver.FindElement(By.Id("country")).SendKeys(testDataParts[3]); // Country
        Thread.Sleep(500);
        driver.FindElement(By.Id("city")).SendKeys(testDataParts[4]); // City
        Thread.Sleep(500);
        driver.FindElement(By.Id("card")).SendKeys(testDataParts[5]); // Card Number
        Thread.Sleep(500);
        driver.FindElement(By.Id("month")).SendKeys(testDataParts[6]); // Month
        Thread.Sleep(500);
        driver.FindElement(By.Id("year")).SendKeys(testDataParts[7]); // Year
        Thread.Sleep(500);

        // Click on the "Purchase" button
        driver.FindElement(By.CssSelector("#orderModal .btn-primary")).Click();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        //// Click on the "OK" button in the confirmation dialog
        //driver.FindElement(By.CssSelector(".confirm")).Click();

        // Kiểm tra xem nút "OK" đã được click thành công hay không
        bool isOKButtonClicked = true;
        try
        {
            // Kiểm tra xem hộp thoại xác nhận đã biến mất
            driver.FindElement(By.CssSelector(".confirm"));
        }
        catch (NoSuchElementException)
        {
            // Nếu không tìm thấy nút "OK", tức là nó đã biến mất sau khi được click
            isOKButtonClicked = false;
        }

        // Kết quả mong đợi là "true" nếu nút "OK" đã được click thành công
        string expectedResult = "True";
        string actualResult = isOKButtonClicked.ToString();
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 24);
        }
        catch (IOException ex)
        {
            // Xử lý ngoại lệ IO ở đây, ví dụ: thử lại sau một khoảng thời gian
            Thread.Sleep(1000); // Đợi 1 giây trước khi thử lại
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 24); // Thử ghi lại
        }

        // Assert để kiểm tra kết quả
        Assert.That(actualResult, Is.EqualTo(expectedResult));

    }
    [Test]
    // Test đặt hàng monitor thành công
    public void OrderMonitorSuccess()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_24"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 25); // Lấy dữ liệu test từ Excel
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl(url); // Sử dụng URL từ dữ liệu test

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on the "Phones" link
        driver.FindElement(By.LinkText(testDataParts[0])).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on the "Samsung galaxy s6" phone
        driver.FindElement(By.LinkText(testDataParts[1])).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on "Add to cart" button
        driver.FindElement(By.LinkText("Add to cart")).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Accept the alert
        driver.SwitchTo().Alert().Accept();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Click on the "Cart" link
        driver.FindElement(By.LinkText("Cart")).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on the "Place Order" button
        driver.FindElement(By.CssSelector(".btn-success")).Click();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Fill in the order details
        driver.FindElement(By.Id("name")).SendKeys(testDataParts[2]); // Name
        Thread.Sleep(500);
        driver.FindElement(By.Id("country")).SendKeys(testDataParts[3]); // Country
        Thread.Sleep(500);
        driver.FindElement(By.Id("city")).SendKeys(testDataParts[4]); // City
        Thread.Sleep(500);
        driver.FindElement(By.Id("card")).SendKeys(testDataParts[5]); // Card Number
        Thread.Sleep(500);
        driver.FindElement(By.Id("month")).SendKeys(testDataParts[6]); // Month
        Thread.Sleep(500);
        driver.FindElement(By.Id("year")).SendKeys(testDataParts[7]); // Year
        Thread.Sleep(500);

        // Click on the "Purchase" button
        driver.FindElement(By.CssSelector("#orderModal .btn-primary")).Click();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        //// Click on the "OK" button in the confirmation dialog
        //driver.FindElement(By.CssSelector(".confirm")).Click();

        // Kiểm tra xem nút "OK" đã được click thành công hay không
        bool isOKButtonClicked = true;
        try
        {
            // Kiểm tra xem hộp thoại xác nhận đã biến mất
            driver.FindElement(By.CssSelector(".confirm"));
        }
        catch (NoSuchElementException)
        {
            // Nếu không tìm thấy nút "OK", tức là nó đã biến mất sau khi được click
            isOKButtonClicked = false;
        }

        // Kết quả mong đợi là "true" nếu nút "OK" đã được click thành công
        string expectedResult = "True";
        string actualResult = isOKButtonClicked.ToString();
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 25);
        }
        catch (IOException ex)
        {
            // Xử lý ngoại lệ IO ở đây, ví dụ: thử lại sau một khoảng thời gian
            Thread.Sleep(1000); // Đợi 1 giây trước khi thử lại
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 25); // Thử ghi lại
        }

        // Assert để kiểm tra kết quả
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }
    [Test]
    // Test đặt hàng điện thoại không nhập thông tin
    public void OrderPhoneWithoutInformation()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_25"; // Tên test case
        string[] testDataParts = excelHelper.GetTestData(testCaseName, 26).Split(',');

        driver.Navigate().GoToUrl("https://www.demoblaze.com/");
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText(testDataParts[0])).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText(testDataParts[1])).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText("Add to cart")).Click();
        Thread.Sleep(1000);
        driver.SwitchTo().Alert().Accept();
        Thread.Sleep(500);
        driver.FindElement(By.LinkText("Cart")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.CssSelector(".btn-success")).Click();
        Thread.Sleep(500);

        // Fill in the order details from Excel data
        driver.FindElement(By.Id("name")).SendKeys(""); // Name
        Thread.Sleep(500);
        driver.FindElement(By.Id("country")).SendKeys(""); // Country
        Thread.Sleep(500);
        driver.FindElement(By.Id("city")).SendKeys(""); // City
        Thread.Sleep(500);
        driver.FindElement(By.Id("card")).SendKeys(""); // Card Number
        Thread.Sleep(500);
        driver.FindElement(By.Id("month")).SendKeys(""); // Month
        Thread.Sleep(500);
        driver.FindElement(By.Id("year")).SendKeys(""); // Year
        Thread.Sleep(500);

        driver.FindElement(By.CssSelector("#orderModal .btn-primary")).Click();
        Thread.Sleep(500);

        // Assert to check the alert message
        Assert.That(driver.SwitchTo().Alert().Text, Is.EqualTo("Please fill out Name and Creditcard."));

        // Kiểm tra kết quả và ghi vào Excel
        string expectedResult = "Please fill out Name and Creditcard."; // Kết quả mong đợi
        string actualResult = driver.SwitchTo().Alert().Text; // Kết quả thực tế
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail"; // Xác định kết quả

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 26);
        }
        catch (IOException ex)
        {
            // Xử lý ngoại lệ IO ở đây, ví dụ: thử lại sau một khoảng thời gian
            Thread.Sleep(1000); // Đợi 1 giây trước khi thử lại
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 26); // Thử ghi lại
        }
    }

    [Test]
    // Test đặt hàng laptop không nhập thông tin
    public void OrderLaptopWithoutInformation()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_26"; // Tên test case
        string[] testDataParts = excelHelper.GetTestData(testCaseName, 27).Split(',');

        driver.Navigate().GoToUrl("https://www.demoblaze.com/");
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText(testDataParts[0])).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText(testDataParts[1])).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText("Add to cart")).Click();
        Thread.Sleep(1000);
        driver.SwitchTo().Alert().Accept();
        Thread.Sleep(500);
        driver.FindElement(By.LinkText("Cart")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.CssSelector(".btn-success")).Click();
        Thread.Sleep(500);

        // Fill in the order details from Excel data
        driver.FindElement(By.Id("name")).SendKeys(""); // Name
        Thread.Sleep(500);
        driver.FindElement(By.Id("country")).SendKeys(""); // Country
        Thread.Sleep(500);
        driver.FindElement(By.Id("city")).SendKeys(""); // City
        Thread.Sleep(500);
        driver.FindElement(By.Id("card")).SendKeys(""); // Card Number
        Thread.Sleep(500);
        driver.FindElement(By.Id("month")).SendKeys(""); // Month
        Thread.Sleep(500);
        driver.FindElement(By.Id("year")).SendKeys(""); // Year
        Thread.Sleep(500);

        driver.FindElement(By.CssSelector("#orderModal .btn-primary")).Click();
        Thread.Sleep(500);

        // Assert to check the alert message
        Assert.That(driver.SwitchTo().Alert().Text, Is.EqualTo("Please fill out Name and Creditcard."));

        // Kiểm tra kết quả và ghi vào Excel
        string expectedResult = "Please fill out Name and Creditcard."; // Kết quả mong đợi
        string actualResult = driver.SwitchTo().Alert().Text; // Kết quả thực tế
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail"; // Xác định kết quả

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 27);
        }
        catch (IOException ex)
        {
            // Xử lý ngoại lệ IO ở đây, ví dụ: thử lại sau một khoảng thời gian
            Thread.Sleep(1000); // Đợi 1 giây trước khi thử lại
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 27); // Thử ghi lại
        }
    }
    [Test]
    // Test đặt hàng monitor không nhập thông tin
    public void OrderMonitorWithoutInformation()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_27"; // Tên test case
        string[] testDataParts = excelHelper.GetTestData(testCaseName, 28).Split(',');

        driver.Navigate().GoToUrl("https://www.demoblaze.com/");
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText(testDataParts[0])).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText(testDataParts[1])).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText("Add to cart")).Click();
        Thread.Sleep(1000);
        driver.SwitchTo().Alert().Accept();
        Thread.Sleep(500);
        driver.FindElement(By.LinkText("Cart")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.CssSelector(".btn-success")).Click();
        Thread.Sleep(500);

        // Fill in the order details from Excel data
        driver.FindElement(By.Id("name")).SendKeys(""); // Name
        Thread.Sleep(500);
        driver.FindElement(By.Id("country")).SendKeys(""); // Country
        Thread.Sleep(500);
        driver.FindElement(By.Id("city")).SendKeys(""); // City
        Thread.Sleep(500);
        driver.FindElement(By.Id("card")).SendKeys(""); // Card Number
        Thread.Sleep(500);
        driver.FindElement(By.Id("month")).SendKeys(""); // Month
        Thread.Sleep(500);
        driver.FindElement(By.Id("year")).SendKeys(""); // Year
        Thread.Sleep(500);

        driver.FindElement(By.CssSelector("#orderModal .btn-primary")).Click();
        Thread.Sleep(500);

        // Assert to check the alert message
        Assert.That(driver.SwitchTo().Alert().Text, Is.EqualTo("Please fill out Name and Creditcard."));

        // Kiểm tra kết quả và ghi vào Excel
        string expectedResult = "Please fill out Name and Creditcard."; // Kết quả mong đợi
        string actualResult = driver.SwitchTo().Alert().Text; // Kết quả thực tế
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail"; // Xác định kết quả

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 28);
        }
        catch (IOException ex)
        {
            // Xử lý ngoại lệ IO ở đây, ví dụ: thử lại sau một khoảng thời gian
            Thread.Sleep(1000); // Đợi 1 giây trước khi thử lại
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 28); // Thử ghi lại
        }
    }
    [Test]
    // Test đặt hàng điện thoại nhập sai định dạng thẻ
    public void OrderPhoneWrongCard()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_28"; // Tên test case
        string[] testDataParts = excelHelper.GetTestData(testCaseName, 29).Split(',');

        driver.Navigate().GoToUrl("https://www.demoblaze.com/");
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText(testDataParts[0])).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText(testDataParts[1])).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText("Add to cart")).Click();
        Thread.Sleep(1000);
        driver.SwitchTo().Alert().Accept();
        Thread.Sleep(500);
        driver.FindElement(By.LinkText("Cart")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.CssSelector(".btn-success")).Click();
        Thread.Sleep(500);

        // Fill in the order details from Excel data
        driver.FindElement(By.Id("name")).SendKeys(testDataParts[2]); // Name
        Thread.Sleep(500);
        driver.FindElement(By.Id("country")).SendKeys(testDataParts[3]); // Country
        Thread.Sleep(500);
        driver.FindElement(By.Id("city")).SendKeys(testDataParts[4]); // City
        Thread.Sleep(500);
        driver.FindElement(By.Id("card")).SendKeys(testDataParts[5]); // Card Number
        Thread.Sleep(500);
        driver.FindElement(By.Id("month")).SendKeys(testDataParts[6]); // Month
        Thread.Sleep(500);
        driver.FindElement(By.Id("year")).SendKeys(testDataParts[7]); // Year
        Thread.Sleep(500);

        driver.FindElement(By.CssSelector("#orderModal .btn-primary")).Click();
        Thread.Sleep(500);

        // Kiểm tra xem nút "OK" đã được click thành công hay không
        bool isOKButtonClicked = false;
        try
        {
            // Kiểm tra xem hộp thoại xác nhận đã biến mất
            driver.FindElement(By.CssSelector(".confirm"));
        }
        catch (NoSuchElementException)
        {
            // Nếu không tìm thấy nút "OK", tức là nó đã biến mất sau khi được click
            isOKButtonClicked = true;
        }

        // Kết quả mong đợi là "true" nếu nút "OK" đã được click thành công
        string expectedResult = "True";
        string actualResult = isOKButtonClicked.ToString();
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 29);
        }
        catch (IOException ex)
        {
            // Xử lý ngoại lệ IO ở đây, ví dụ: thử lại sau một khoảng thời gian
            Thread.Sleep(1000); // Đợi 1 giây trước khi thử lại
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 29); // Thử ghi lại
        }

        // Assert để kiểm tra kết quả
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }

    [Test]
    // Test đặt hàng laptop nhập sai định dạng thẻ
    public void OrderLaptopWrongCard()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_29"; // Tên test case
        string[] testDataParts = excelHelper.GetTestData(testCaseName, 30).Split(',');

        driver.Navigate().GoToUrl("https://www.demoblaze.com/");
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText(testDataParts[0])).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText(testDataParts[1])).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText("Add to cart")).Click();
        Thread.Sleep(1000);
        driver.SwitchTo().Alert().Accept();
        Thread.Sleep(500);
        driver.FindElement(By.LinkText("Cart")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.CssSelector(".btn-success")).Click();
        Thread.Sleep(500);

        // Fill in the order details from Excel data
        driver.FindElement(By.Id("name")).SendKeys(testDataParts[2]); // Name
        Thread.Sleep(500);
        driver.FindElement(By.Id("country")).SendKeys(testDataParts[3]); // Country
        Thread.Sleep(500);
        driver.FindElement(By.Id("city")).SendKeys(testDataParts[4]); // City
        Thread.Sleep(500);
        driver.FindElement(By.Id("card")).SendKeys(testDataParts[5]); // Card Number
        Thread.Sleep(500);
        driver.FindElement(By.Id("month")).SendKeys(testDataParts[6]); // Month
        Thread.Sleep(500);
        driver.FindElement(By.Id("year")).SendKeys(testDataParts[7]); // Year
        Thread.Sleep(500);

        driver.FindElement(By.CssSelector("#orderModal .btn-primary")).Click();
        Thread.Sleep(500);

        // Kiểm tra xem nút "OK" đã được click thành công hay không
        bool isOKButtonClicked = false;
        try
        {
            // Kiểm tra xem hộp thoại xác nhận đã biến mất
            driver.FindElement(By.CssSelector(".confirm"));
        }
        catch (NoSuchElementException)
        {
            // Nếu không tìm thấy nút "OK", tức là nó đã biến mất sau khi được click
            isOKButtonClicked = true;
        }

        // Kết quả mong đợi là "true" nếu nút "OK" đã được click thành công
        string expectedResult = "True";
        string actualResult = isOKButtonClicked.ToString();
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 30);
        }
        catch (IOException ex)
        {
            // Xử lý ngoại lệ IO ở đây, ví dụ: thử lại sau một khoảng thời gian
            Thread.Sleep(1000); // Đợi 1 giây trước khi thử lại
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 30); // Thử ghi lại
        }

        // Assert để kiểm tra kết quả
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }
    [Test]
    // Test đặt hàng monitor nhập sai định dạng thẻ
    public void OrderMonitorWrongCard()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_30"; // Tên test case
        string[] testDataParts = excelHelper.GetTestData(testCaseName, 31).Split(',');

        driver.Navigate().GoToUrl("https://www.demoblaze.com/");
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText(testDataParts[0])).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText(testDataParts[1])).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.LinkText("Add to cart")).Click();
        Thread.Sleep(1000);
        driver.SwitchTo().Alert().Accept();
        Thread.Sleep(500);
        driver.FindElement(By.LinkText("Cart")).Click();
        Thread.Sleep(1000);
        driver.FindElement(By.CssSelector(".btn-success")).Click();
        Thread.Sleep(500);

        // Fill in the order details from Excel data
        driver.FindElement(By.Id("name")).SendKeys(testDataParts[2]); // Name
        Thread.Sleep(500);
        driver.FindElement(By.Id("country")).SendKeys(testDataParts[3]); // Country
        Thread.Sleep(500);
        driver.FindElement(By.Id("city")).SendKeys(testDataParts[4]); // City
        Thread.Sleep(500);
        driver.FindElement(By.Id("card")).SendKeys(testDataParts[5]); // Card Number
        Thread.Sleep(500);
        driver.FindElement(By.Id("month")).SendKeys(testDataParts[6]); // Month
        Thread.Sleep(500);
        driver.FindElement(By.Id("year")).SendKeys(testDataParts[7]); // Year
        Thread.Sleep(500);

        driver.FindElement(By.CssSelector("#orderModal .btn-primary")).Click();
        Thread.Sleep(500);

        // Kiểm tra xem nút "OK" đã được click thành công hay không
        bool isOKButtonClicked = false;
        try
        {
            // Kiểm tra xem hộp thoại xác nhận đã biến mất
            driver.FindElement(By.CssSelector(".confirm"));
        }
        catch (NoSuchElementException)
        {
            // Nếu không tìm thấy nút "OK", tức là nó đã biến mất sau khi được click
            isOKButtonClicked = true;
        }

        // Kết quả mong đợi là "true" nếu nút "OK" đã được click thành công
        string expectedResult = "True";
        string actualResult = isOKButtonClicked.ToString();
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 31);
        }
        catch (IOException ex)
        {
            // Xử lý ngoại lệ IO ở đây, ví dụ: thử lại sau một khoảng thời gian
            Thread.Sleep(1000); // Đợi 1 giây trước khi thử lại
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 31); // Thử ghi lại
        }

        // Assert để kiểm tra kết quả
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }
    [Test]
    // Test đặt hàng điện thoại không nhập tên
    public void OrderPhoneWithoutName()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_31"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 32); // Lấy dữ liệu test từ Excel
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl(url); // Sử dụng URL từ dữ liệu test

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on the "Phones" link
        driver.FindElement(By.LinkText(testDataParts[0])).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on the "Samsung galaxy s6" phone
        driver.FindElement(By.LinkText(testDataParts[1])).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on "Add to cart" button
        driver.FindElement(By.LinkText("Add to cart")).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Accept the alert
        driver.SwitchTo().Alert().Accept();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Click on the "Cart" link
        driver.FindElement(By.LinkText("Cart")).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on the "Place Order" button
        driver.FindElement(By.CssSelector(".btn-success")).Click();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Fill in the order details
        driver.FindElement(By.Id("name")).SendKeys(""); // Name
        Thread.Sleep(500);
        driver.FindElement(By.Id("country")).SendKeys(testDataParts[2]); // Country
        Thread.Sleep(500);
        driver.FindElement(By.Id("city")).SendKeys(testDataParts[3]); // City
        Thread.Sleep(500);
        driver.FindElement(By.Id("card")).SendKeys(testDataParts[4]); // Card Number
        Thread.Sleep(500);
        driver.FindElement(By.Id("month")).SendKeys(testDataParts[5]); // Month
        Thread.Sleep(500);
        driver.FindElement(By.Id("year")).SendKeys(testDataParts[6]); // Year
        Thread.Sleep(500);

        // Click on the "Purchase" button
        driver.FindElement(By.CssSelector("#orderModal .btn-primary")).Click();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        //// Click on the "OK" button in the confirmation dialog
        //driver.FindElement(By.CssSelector(".confirm")).Click();

        // Kiểm tra xem nút "OK" đã được click thành công hay không
        string expectedResult = "Please fill out Name and Creditcard.";
        string actualResult = driver.SwitchTo().Alert().Text;
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 32);
        }
        catch (IOException ex)
        {
            // Xử lý ngoại lệ IO ở đây, ví dụ: thử lại sau một khoảng thời gian
            Thread.Sleep(1000); // Đợi 1 giây trước khi thử lại
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 32); // Thử ghi lại
        }

        // Assert để kiểm tra kết quả
        Assert.That(actualResult, Is.EqualTo(expectedResult));

    }
    [Test]
    // Test đặt hàng laptop không nhập tên
    public void OrderLaptopWithoutName()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_32"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 33); // Lấy dữ liệu test từ Excel
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl(url); // Sử dụng URL từ dữ liệu test

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        driver.FindElement(By.LinkText(testDataParts[0])).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        driver.FindElement(By.LinkText(testDataParts[1])).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on "Add to cart" button
        driver.FindElement(By.LinkText("Add to cart")).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Accept the alert
        driver.SwitchTo().Alert().Accept();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Click on the "Cart" link
        driver.FindElement(By.LinkText("Cart")).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on the "Place Order" button
        driver.FindElement(By.CssSelector(".btn-success")).Click();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Fill in the order details
        driver.FindElement(By.Id("name")).SendKeys(""); // Name
        Thread.Sleep(500);
        driver.FindElement(By.Id("country")).SendKeys(testDataParts[2]); // Country
        Thread.Sleep(500);
        driver.FindElement(By.Id("city")).SendKeys(testDataParts[3]); // City
        Thread.Sleep(500);
        driver.FindElement(By.Id("card")).SendKeys(testDataParts[4]); // Card Number
        Thread.Sleep(500);
        driver.FindElement(By.Id("month")).SendKeys(testDataParts[5]); // Month
        Thread.Sleep(500);
        driver.FindElement(By.Id("year")).SendKeys(testDataParts[6]); // Year
        Thread.Sleep(500);

        // Click on the "Purchase" button
        driver.FindElement(By.CssSelector("#orderModal .btn-primary")).Click();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        //// Click on the "OK" button in the confirmation dialog
        //driver.FindElement(By.CssSelector(".confirm")).Click();

        // Kiểm tra xem nút "OK" đã được click thành công hay không
        string expectedResult = "Please fill out Name and Creditcard.";
        string actualResult = driver.SwitchTo().Alert().Text;
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 33);
        }
        catch (IOException ex)
        {
            // Xử lý ngoại lệ IO ở đây, ví dụ: thử lại sau một khoảng thời gian
            Thread.Sleep(1000); // Đợi 1 giây trước khi thử lại
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 33); // Thử ghi lại
        }

        // Assert để kiểm tra kết quả
        Assert.That(actualResult, Is.EqualTo(expectedResult));

    }
    [Test]
    // Test đặt hàng monitor không nhập tên
    public void OrderMonitorWithoutName()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_33"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 34); // Lấy dữ liệu test từ Excel
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl(url); // Sử dụng URL từ dữ liệu test

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        driver.FindElement(By.LinkText(testDataParts[0])).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        driver.FindElement(By.LinkText(testDataParts[1])).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on "Add to cart" button
        driver.FindElement(By.LinkText("Add to cart")).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Accept the alert
        driver.SwitchTo().Alert().Accept();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Click on the "Cart" link
        driver.FindElement(By.LinkText("Cart")).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on the "Place Order" button
        driver.FindElement(By.CssSelector(".btn-success")).Click();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Fill in the order details
        driver.FindElement(By.Id("name")).SendKeys(""); // Name
        Thread.Sleep(500);
        driver.FindElement(By.Id("country")).SendKeys(testDataParts[2]); // Country
        Thread.Sleep(500);
        driver.FindElement(By.Id("city")).SendKeys(testDataParts[3]); // City
        Thread.Sleep(500);
        driver.FindElement(By.Id("card")).SendKeys(testDataParts[4]); // Card Number
        Thread.Sleep(500);
        driver.FindElement(By.Id("month")).SendKeys(testDataParts[5]); // Month
        Thread.Sleep(500);
        driver.FindElement(By.Id("year")).SendKeys(testDataParts[6]); // Year
        Thread.Sleep(500);

        // Click on the "Purchase" button
        driver.FindElement(By.CssSelector("#orderModal .btn-primary")).Click();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        //// Click on the "OK" button in the confirmation dialog
        //driver.FindElement(By.CssSelector(".confirm")).Click();

        // Kiểm tra xem nút "OK" đã được click thành công hay không
        string expectedResult = "Please fill out Name and Creditcard.";
        string actualResult = driver.SwitchTo().Alert().Text;
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 34);
        }
        catch (IOException ex)
        {
            // Xử lý ngoại lệ IO ở đây, ví dụ: thử lại sau một khoảng thời gian
            Thread.Sleep(1000); // Đợi 1 giây trước khi thử lại
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 34); // Thử ghi lại
        }

        // Assert để kiểm tra kết quả
        Assert.That(actualResult, Is.EqualTo(expectedResult));

    }
    [Test]
    // Test đặt hàng điện thoại không nhập tên và thẻ
    public void OrderPhoneWithoutNameAndCard()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_34"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 35); // Lấy dữ liệu test từ Excel
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl(url); // Sử dụng URL từ dữ liệu test

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        driver.FindElement(By.LinkText(testDataParts[0])).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        driver.FindElement(By.LinkText(testDataParts[1])).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on "Add to cart" button
        driver.FindElement(By.LinkText("Add to cart")).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Accept the alert
        driver.SwitchTo().Alert().Accept();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Click on the "Cart" link
        driver.FindElement(By.LinkText("Cart")).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on the "Place Order" button
        driver.FindElement(By.CssSelector(".btn-success")).Click();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Fill in the order details
        driver.FindElement(By.Id("name")).SendKeys(""); // Name
        Thread.Sleep(500);
        driver.FindElement(By.Id("country")).SendKeys(testDataParts[2]); // Country
        Thread.Sleep(500);
        driver.FindElement(By.Id("city")).SendKeys(testDataParts[3]); // City
        Thread.Sleep(500);
        driver.FindElement(By.Id("card")).SendKeys(""); // Card Number
        Thread.Sleep(500);
        driver.FindElement(By.Id("month")).SendKeys(testDataParts[4]); // Month
        Thread.Sleep(500);
        driver.FindElement(By.Id("year")).SendKeys(testDataParts[5]); // Year
        Thread.Sleep(500);

        // Click on the "Purchase" button
        driver.FindElement(By.CssSelector("#orderModal .btn-primary")).Click();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        //// Click on the "OK" button in the confirmation dialog
        //driver.FindElement(By.CssSelector(".confirm")).Click();

        // Kiểm tra xem nút "OK" đã được click thành công hay không
        string expectedResult = "Please fill out Name and Creditcard.";
        string actualResult = driver.SwitchTo().Alert().Text;
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 35);
        }
        catch (IOException ex)
        {
            // Xử lý ngoại lệ IO ở đây, ví dụ: thử lại sau một khoảng thời gian
            Thread.Sleep(1000); // Đợi 1 giây trước khi thử lại
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 35); // Thử ghi lại
        }

        // Assert để kiểm tra kết quả
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }
    [Test]
    // Test đặt hàng laptop không nhập tên và thẻ
    public void OrderLaptopWithoutNameAndCard()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_35"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 36); // Lấy dữ liệu test từ Excel
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl(url); // Sử dụng URL từ dữ liệu test

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        driver.FindElement(By.LinkText(testDataParts[0])).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        driver.FindElement(By.LinkText(testDataParts[1])).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on "Add to cart" button
        driver.FindElement(By.LinkText("Add to cart")).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Accept the alert
        driver.SwitchTo().Alert().Accept();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Click on the "Cart" link
        driver.FindElement(By.LinkText("Cart")).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on the "Place Order" button
        driver.FindElement(By.CssSelector(".btn-success")).Click();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Fill in the order details
        driver.FindElement(By.Id("name")).SendKeys(""); // Name
        Thread.Sleep(500);
        driver.FindElement(By.Id("country")).SendKeys(testDataParts[2]); // Country
        Thread.Sleep(500);
        driver.FindElement(By.Id("city")).SendKeys(testDataParts[3]); // City
        Thread.Sleep(500);
        driver.FindElement(By.Id("card")).SendKeys(""); // Card Number
        Thread.Sleep(500);
        driver.FindElement(By.Id("month")).SendKeys(testDataParts[4]); // Month
        Thread.Sleep(500);
        driver.FindElement(By.Id("year")).SendKeys(testDataParts[5]); // Year
        Thread.Sleep(500);

        // Click on the "Purchase" button
        driver.FindElement(By.CssSelector("#orderModal .btn-primary")).Click();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        //// Click on the "OK" button in the confirmation dialog
        //driver.FindElement(By.CssSelector(".confirm")).Click();

        // Kiểm tra xem nút "OK" đã được click thành công hay không
        string expectedResult = "Please fill out Name and Creditcard.";
        string actualResult = driver.SwitchTo().Alert().Text;
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 36);
        }
        catch (IOException ex)
        {
            // Xử lý ngoại lệ IO ở đây, ví dụ: thử lại sau một khoảng thời gian
            Thread.Sleep(1000); // Đợi 1 giây trước khi thử lại
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 36); // Thử ghi lại
        }

        // Assert để kiểm tra kết quả
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }
    [Test]
    // Test đặt hàng monitor không nhập tên và thẻ
    public void OrderMonitorWithoutNameAndCard()
    {
        // Đường dẫn tới file Excel chứa test case
        string excelFilePath = "/Users/votrankhanhdang/Desktop/datatestmobie.xlsx";
        // Khởi tạo đối tượng ExcelHelper
        ExcelHelper excelHelper = new ExcelHelper(excelFilePath);

        // Đọc dữ liệu test từ file Excel
        string testCaseName = "TC_37"; // Tên test case
        string testData = excelHelper.GetTestData(testCaseName, 38); // Lấy dữ liệu test từ Excel
        string[] testDataParts = testData.Split(',');

        // Navigate to the website
        driver.Navigate().GoToUrl(url); // Sử dụng URL từ dữ liệu test

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        driver.FindElement(By.LinkText(testDataParts[0])).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        driver.FindElement(By.LinkText(testDataParts[1])).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on "Add to cart" button
        driver.FindElement(By.LinkText("Add to cart")).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Accept the alert
        driver.SwitchTo().Alert().Accept();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Click on the "Cart" link
        driver.FindElement(By.LinkText("Cart")).Click();

        // Wait for 1000 milliseconds
        Thread.Sleep(1000);

        // Click on the "Place Order" button
        driver.FindElement(By.CssSelector(".btn-success")).Click();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        // Fill in the order details
        driver.FindElement(By.Id("name")).SendKeys(""); // Name
        Thread.Sleep(500);
        driver.FindElement(By.Id("country")).SendKeys(testDataParts[2]); // Country
        Thread.Sleep(500);
        driver.FindElement(By.Id("city")).SendKeys(testDataParts[3]); // City
        Thread.Sleep(500);
        driver.FindElement(By.Id("card")).SendKeys(""); // Card Number
        Thread.Sleep(500);
        driver.FindElement(By.Id("month")).SendKeys(testDataParts[4]); // Month
        Thread.Sleep(500);
        driver.FindElement(By.Id("year")).SendKeys(testDataParts[5]); // Year
        Thread.Sleep(500);

        // Click on the "Purchase" button
        driver.FindElement(By.CssSelector("#orderModal .btn-primary")).Click();

        // Wait for 500 milliseconds
        Thread.Sleep(500);

        //// Click on the "OK" button in the confirmation dialog
        //driver.FindElement(By.CssSelector(".confirm")).Click();

        // Kiểm tra xem nút "OK" đã được click thành công hay không
        string expectedResult = "Please fill out Name and Creditcard.";
        string actualResult = driver.SwitchTo().Alert().Text;
        string passOrFail = (actualResult == expectedResult) ? "pass" : "fail";

        // Write the result to Excel
        try
        {
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 38);
        }
        catch (IOException ex)
        {
            // Xử lý ngoại lệ IO ở đây, ví dụ: thử lại sau một khoảng thời gian
            Thread.Sleep(1000); // Đợi 1 giây trước khi thử lại
            excelHelper.WriteResultToExcel(testCaseName, expectedResult, actualResult, passOrFail, 38); // Thử ghi lại
        }

        // Assert để kiểm tra kết quả
        Assert.That(actualResult, Is.EqualTo(expectedResult));
    }
}
